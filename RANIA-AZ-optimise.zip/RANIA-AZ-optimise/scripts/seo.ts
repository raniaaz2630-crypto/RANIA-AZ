/**
 * Étape SEO exécutée automatiquement après `vite build` (voir package.json).
 * Elle écrit dans le dossier dist/ :
 *  - index.html enrichi : balises, données structurées, texte lisible sans JavaScript
 *  - une page statique par soin : dist/soins/<id>/index.html
 *  - sitemap.xml et robots.txt
 * Source unique des informations : src/data/clinicData.ts (aucune donnée dupliquée).
 *
 * Adresse du site : variable SITE_URL (ex. https://www.dr-azzouzi.ma).
 * Sans SITE_URL, les liens absolus (canonical, sitemap) sont volontairement omis.
 */
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { CLINIC_CONTACT, SPECIALTIES, FAQ_ITEMS } from '../src/data/clinicData';

const SITE_URL = (process.env.SITE_URL || '').replace(/\/+$/, '');
const DIST = new URL('../dist/', import.meta.url);
const template = readFileSync(new URL('index.html', DIST), 'utf-8');

const esc = (s: string) =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const abs = (path: string) => (SITE_URL ? `${SITE_URL}${path}` : '');

// Horaires -> format schema.org
const DAY_MAP: Record<string, string[]> = {
  'Lundi - Vendredi': ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
  Samedi: ['Saturday'],
};
const openingHours = CLINIC_CONTACT.hours
  .filter((h) => DAY_MAP[h.day] && /\d/.test(h.time))
  .map((h) => {
    const [opens, closes] = h.time.split('-').map((t) => t.trim());
    return { '@type': 'OpeningHoursSpecification', dayOfWeek: DAY_MAP[h.day], opens, closes };
  });

const clinicLd = {
  '@context': 'https://schema.org',
  '@type': ['Dentist', 'LocalBusiness'],
  '@id': abs('/#cabinet') || undefined,
  name: 'Cabinet Dentaire Dr. Rania Azzouzi',
  description:
    "Cabinet de chirurgie dentaire et d'esthétique du sourire à Tanger : implants, orthodontie, facettes, urgences.",
  url: abs('/') || undefined,
  telephone: CLINIC_CONTACT.phone,
  email: CLINIC_CONTACT.email,
  image: CLINIC_CONTACT.doctorImage,
  address: {
    '@type': 'PostalAddress',
    streetAddress: CLINIC_CONTACT.address.split(',')[0].trim(),
    addressLocality: 'Tanger',
    addressCountry: 'MA',
  },
  openingHoursSpecification: openingHours,
  medicalSpecialty: ['Dentistry', 'Orthodontics'],
  founder: {
    '@type': 'Physician',
    name: CLINIC_CONTACT.name,
    jobTitle: CLINIC_CONTACT.title,
    medicalSpecialty: 'Dentistry',
  },
  availableLanguage: ['fr', 'ar', 'es'],
};

const faqLd = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: FAQ_ITEMS.map((f) => ({
    '@type': 'Question',
    name: f.question,
    acceptedAnswer: { '@type': 'Answer', text: f.answer },
  })),
};

const ld = (o: unknown) =>
  `<script type="application/ld+json">${JSON.stringify(o).replace(/</g, '\\u003c')}</script>`;

const contactBlock = `<p>${esc(CLINIC_CONTACT.name)} — ${esc(CLINIC_CONTACT.title)}<br>${esc(
  CLINIC_CONTACT.address
)}<br>Téléphone : ${esc(CLINIC_CONTACT.phone)}<br>${CLINIC_CONTACT.hours
  .map((h) => `${esc(h.day)} : ${esc(h.time)}`)
  .join(' — ')}</p>`;

const servicesList = `<ul>${SPECIALTIES.map(
  (s) => `<li><a href="/soins/${s.id}/"><strong>${esc(s.title)}</strong></a> : ${esc(s.shortDesc)}</li>`
).join('')}</ul>`;

function page(opts: { title: string; description: string; path: string; head?: string; body: string }) {
  const canonical = abs(opts.path);
  let html = template
    .replace(/<title>[\s\S]*?<\/title>/, `<title>${esc(opts.title)}</title>`)
    .replace(
      /<meta name="description"[^>]*>/,
      `<meta name="description" content="${esc(opts.description)}" />`
    )
    .replace(
      /<meta property="og:title"[^>]*>/,
      `<meta property="og:title" content="${esc(opts.title)}" />`
    )
    .replace(
      /<meta property="og:description"[^>]*>/,
      `<meta property="og:description" content="${esc(opts.description)}" />`
    )
    .replace(
      '<!--SEO_HEAD-->',
      [
        canonical && `<link rel="canonical" href="${canonical}" />`,
        canonical && `<meta property="og:url" content="${canonical}" />`,
        `<meta property="og:image" content="${esc(CLINIC_CONTACT.heroImage)}" />`,
        opts.head || '',
      ]
        .filter(Boolean)
        .join('\n    ')
    )
    .replace('<!--SEO_ROOT-->', opts.body);
  return html;
}

// ---------- Accueil ----------
const home = page({
  title: 'Dentiste à Tanger | Cabinet Dentaire Dr. Rania Azzouzi',
  description:
    'Cabinet dentaire à Tanger : implants, orthodontie, facettes et esthétique du sourire avec le Dr. Rania Azzouzi. Urgences dentaires, rendez-vous par WhatsApp.',
  path: '/',
  head: [ld(clinicLd), ld(faqLd)].join('\n    '),
  body: `<main><h1>Cabinet dentaire à Tanger — Dr. Rania Azzouzi</h1>
<p>${esc(CLINIC_CONTACT.title)}. Implants dentaires, orthodontie, facettes, blanchiment et soins conservateurs à Tanger.</p>
<h2>Nos soins dentaires à Tanger</h2>${servicesList}
<h2>Questions fréquentes</h2>${FAQ_ITEMS.map(
    (f) => `<h3>${esc(f.question)}</h3><p>${esc(f.answer)}</p>`
  ).join('')}
<h2>Contact et horaires</h2>${contactBlock}</main>`,
});
writeFileSync(new URL('index.html', DIST), home);

// ---------- Une page par soin ----------
for (const s of SPECIALTIES) {
  const path = `/soins/${s.id}/`;
  const title = `${s.title} à Tanger | Dr. Rania Azzouzi`;
  const description = `${s.shortDesc} Cabinet dentaire à Tanger, Dr. Rania Azzouzi.`.slice(0, 300);
  const serviceLd = {
    '@context': 'https://schema.org',
    '@type': 'MedicalProcedure',
    name: s.title,
    description: s.fullDesc,
    procedureType: 'https://schema.org/NoninvasiveProcedure',
  };
  const html = page({
    title,
    description,
    path,
    head: [ld(clinicLd), ld(serviceLd)].join('\n    '),
    body: `<main><h1>${esc(s.title)} à Tanger</h1><p>${esc(s.fullDesc)}</p>
<h2>Les avantages</h2><ul>${s.benefits.map((b) => `<li>${esc(b)}</li>`).join('')}</ul>
<p>Durée estimée : ${esc(s.durationEstimate)}. Anesthésie : ${esc(s.anesthesiaType)}.</p>
<p><a href="/">Retour à l'accueil</a></p>
<h2>Contact et horaires</h2>${contactBlock}</main>`,
  });
  mkdirSync(new URL(`soins/${s.id}/`, DIST), { recursive: true });
  writeFileSync(new URL(`soins/${s.id}/index.html`, DIST), html);
}

// ---------- sitemap.xml et robots.txt ----------
if (SITE_URL) {
  const urls = ['/', ...SPECIALTIES.map((s) => `/soins/${s.id}/`)];
  const today = new Date().toISOString().slice(0, 10);
  writeFileSync(
    new URL('sitemap.xml', DIST),
    `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls
      .map((u) => `  <url><loc>${SITE_URL}${u}</loc><lastmod>${today}</lastmod></url>`)
      .join('\n')}\n</urlset>\n`
  );
} else {
  console.warn('[seo] SITE_URL absent : sitemap.xml et balises canonical non générés.');
}
writeFileSync(
  new URL('robots.txt', DIST),
  `User-agent: *\nAllow: /\n${SITE_URL ? `\nSitemap: ${SITE_URL}/sitemap.xml\n` : ''}`
);
console.log(`[seo] ${1 + SPECIALTIES.length} pages générées.`);
