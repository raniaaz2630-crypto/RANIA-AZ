import { CLINIC_CONTACT } from '../data/clinicData';

interface BookingRequest {
  name: string;
  phone: string;
  email?: string;
  service: string;
  date?: string;
  slot?: string;
  message?: string;
}

/**
 * Construit le lien WhatsApp qui contient la demande de rendez-vous.
 * La demande arrive ainsi réellement au cabinet (aucun serveur nécessaire).
 */
export function buildBookingWhatsAppUrl(r: BookingRequest): string {
  const lines = [
    'Bonjour Dr. Azzouzi, je souhaite prendre rendez-vous.',
    `Nom : ${r.name}`,
    `Téléphone : ${r.phone}`,
    r.email ? `E-mail : ${r.email}` : '',
    `Soin : ${r.service}`,
    r.date ? `Date souhaitée : ${r.date}` : '',
    r.slot ? `Créneau : ${r.slot}` : '',
    r.message ? `Message : ${r.message}` : '',
  ].filter(Boolean);
  return `https://wa.me/${CLINIC_CONTACT.whatsappNumber}?text=${encodeURIComponent(lines.join('\n'))}`;
}
